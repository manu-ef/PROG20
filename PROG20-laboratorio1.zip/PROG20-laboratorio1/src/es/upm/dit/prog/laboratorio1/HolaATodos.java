package es.upm.dit.prog.laboratorio1;

public class HolaATodos {

	public static void main(String[] args) {
		System.out.println("Hola a todos");

	}

}
