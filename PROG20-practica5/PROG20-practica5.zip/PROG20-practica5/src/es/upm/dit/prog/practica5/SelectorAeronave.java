package es.upm.dit.prog.practica5;

public interface SelectorAeronave {
	
	public boolean seleccionar(Aeronave ae);
	
}
